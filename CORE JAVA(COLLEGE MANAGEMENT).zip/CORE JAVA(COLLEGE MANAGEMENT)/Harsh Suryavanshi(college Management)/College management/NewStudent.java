package School;

	import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

	public class NewStudent extends Teachers{

		public static void main(String[] args) throws ClassNotFoundException, SQLException {
			// TODO Auto-generated method stub
			Reuse r=new Reuse();

			System.out.println("Enter Data For Student");
			
			
			Scanner sc=new  Scanner(System.in);
			System.out.println("Enter Id: ");
			int Id =sc.nextInt();
			if(Id>0) {
				
			
			System.out.println("Enter Name: ");
			String Name =sc.next();
			
			
			System.out.println("Enter Date of birth: ");
			String dob=sc.next();
			
		
			System.out.println("Enter Your State name: ");
			String State=sc.next();
			
			
			System.out.println("Enter your city name: ");
			String City=sc.next();
			
		
			System.out.println("Enter Mobile no without country code: ");
			String Phone =sc.next();
			if( 10==Phone.length())
			{
				
				System.out.println("______________________________________________________________________");

			}
			else {
				System.out.println("Please enter only 10 values");
				
					r.Reuse1();
					
				
			}
			System.out.println("______________________________________________________________________");

			System.out.println("Enter Email: ");
			String Email =sc.nextLine();
			
			System.out.println("______________________________________________________________________");
			System.out.println(Id+" "+Name+" "+dob+" "+State+" "+City+" "+Phone+" "+Email+" ");
		
		}else {
			System.out.println("Please input positive values");
		}
			Connection con=null;
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/clg","root","");
			
			
			
			Statement stmt11=con.createStatement();
			 
		} 
	}
	
