package School;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

class  JDBC1 extends NewStudent{
public void connection1()
{try
	{
	
	
	Connection con=null;
	con=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","");
	Statement stmt=con.createStatement();
	String sqlqueryd="create database clg";
	stmt.executeUpdate(sqlqueryd);
	System.out.println("Database created");
	
	
	
	

	String sqlquery=" create table clg.teacher(id int,fname varchar(20),dept varchar(20),jdate date,accno long,gender varchar(20),address varchar(20),phone long)";
	stmt.executeUpdate(sqlquery);
System.out.println("teacher Table  created");





 sqlquery=" create table clg.student(Id int,Name varchar(20),dob date,State varchar(20),City varchar(20),Phone long,Email varchar(20))";
stmt.executeUpdate(sqlquery);
System.out.println("student Table  created");

con.close();
	}catch(Exception e)
	{
		System.out.println(e);
		
	}
}
}
public class JDBC {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

	
	}
	

}
