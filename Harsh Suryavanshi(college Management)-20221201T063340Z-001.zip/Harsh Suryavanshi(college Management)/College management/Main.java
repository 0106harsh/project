package School;

import java.sql.JDBCType;
import java.sql.SQLException;
import java.util.Scanner;
import School.*;
import java.sql.SQLException;
public class Main {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		JDBC1 j=new JDBC1();
		j.connection1();
		
		Scanner sc=new Scanner(System.in);

		int choice=0;
		do {
			System.out.println("1 For Teachers, 2 For Student , 3 For Update, 0 For Exit");
			System.out.print("select any one : ");
			choice=sc.nextInt();
			switch(choice) {
			case 1:
				Teachers.main(args);
				
				break;
			case 2:
				NewStudent.main(args);
				break;
			case 3:
				Update.main(args);
				break;
				default:
					break;
			
			}
			
		}
		while (choice!=0);
		
		
	}

}
