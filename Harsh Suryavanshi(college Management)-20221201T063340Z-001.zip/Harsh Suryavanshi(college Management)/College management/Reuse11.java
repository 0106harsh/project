package School;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
class Reuse
{

	

	 void Reuse1() throws ClassNotFoundException, SQLException
	{
		Scanner sc=new Scanner(System.in);
System.out.println("\n"+"\n");
		int choice=0;
		do {
			System.out.println("1 For Teachers, 2 For Student , 3 For Update, 0 For Exit");
			System.out.print("Enter Yout chhoice: ");
			choice=sc.nextInt();
			String[] args = null;
			switch(choice) {
			case 1:
				Teachers.main(args);
				break;
			case 2:
				NewStudent.main(args);
				break;
			case 3:
				Update.main(args);
				break;
				default:
					break;
			
			}
			
		}
		while (choice!=0);
		
		
	
	

}
}
public class Reuse11 {

	public static void  main(String[] args)
	{

	
				
	}
	}

