package School;
import java.io.FileNotFoundException;
import java.sql.*;
	import java.util.Scanner;

	public class Teachers extends Main {

		public static void main(String[] args) throws SQLException, ClassNotFoundException,NullPointerException {
			// TODO Auto-generated method stub
			Reuse r=new Reuse();

			
			Scanner sc=new  Scanner(System.in);
			System.out.println("Enter ID: ");
			int id =sc.nextInt();
			System.out.println("Enter name: ");
			String FName =sc.next();
			
			
			
			System.out.println("Enter Department (SCIENCE ,COMMERCE, ARTS): ");
			String Dep =sc.next();
			
		
			System.out.println("Enter Joining Date: ");
			String JDate =sc.next();
			
				
			System.out.println("Enter Account no ");
			String Account =sc.next();
			
				System.out.println("Enter Gender: ");
				String Gender=sc.next();
				

				
				System.out.println("Enter Address/City: ");
				String Address =sc.next();
				
				
				System.out.println("Enter Mobile no without country code: ");
				String Phone=sc.next();
				if( 10==Phone.length())
				{
					
					System.out.println("______________________________________________________________________");

				}
				else {
					System.out.println("Please enter only 10 values");
					
						r.Reuse1();
						
					
				}
				System.out.println("______________________________________________________________________");

					

					System.out.println("_______________________________________________________________________________________________________________________________________________________");
				System.out.println("id: "+id+" "+"\t"+"Full name: "+FName+" "+"\t"+"Dept: " +Dep+" "+"\t"+"Joining Date: " +JDate+" "+"\t"+"Acc.No" +Account+" "+"\t"+"Gender: " +Gender+" "+"\t"+"Add: " +Address+" "+"\t"+"Phone: " +Phone);
				System.out.println("_______________________________________________________________________________________________________________________________________________________");
			
				
				Connection con=null;
				con=DriverManager.getConnection("jdbc:mysql://localhost:3306/clg","root","");
				
				
				
				Statement stmt11=con.createStatement();
				 
				 stmt11.executeUpdate("insert into clg.teacher values ('"+id+"','"+FName+"','"+Dep+"','"+JDate+"','"+Account+"','"+Gender+"','"+Address+"','"+Phone+"')");
			          
			      System.out.println("record inserted");
			
			      
			      System.out.println("Enter 1. to update Teacher Id ");
			      System.out.println("Enter 2. to update Teacher Name");
			      System.out.println("Enter 3. to update Teacher Phone no ");

int ch=sc.nextInt();
switch(ch)
{
case 1: 
	

	 con=DriverManager.getConnection("jdbc:mysql://localhost:3306/clg","root","");
	 System.out.println("new id");
	 int New_Id =sc.nextInt();
	 System.out.println("old id");
	  id = sc.nextInt();
	String sqlquery1=" Update teacher set id='"+New_Id+"' where id='"+id+"'";
   stmt11.executeUpdate(sqlquery1);
 /*  if(id==New_Id)
   {
   	System.out.println("\n"+"[]");
   	System.out.println("Teacher id update:");
        con.close();
		                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         System.out.println("\n"+"___________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________");

		
   }
   else
   {
			 System.out.println("\n"+"[]");
        System.out.println("Id not update ");
   }*/
   break ;
   
   
   case 2:
	   con=DriverManager.getConnection("jdbc:mysql://localhost:3306/clg","root","");
		 System.out.println("new Name");
		 String New_FName =sc.next();
		 System.out.println("id");
		  id = sc.nextInt();
		  String sqlquery2=" Update teacher set FName='"+New_FName+"' where FName='"+id+"'";
	   stmt11.executeUpdate(sqlquery2);
   
   break;
   
   case 3:
	   con=DriverManager.getConnection("jdbc:mysql://localhost:3306/clg","root","");
		 System.out.println("new Phone");
		 long New_Phone =sc.nextLong();
		 System.out.println("id");
		  id = sc.nextInt();	
		  String sqlquery3=" Update teacher set Phone='"+New_Phone+"' where Phone='"+id+"'";
	   stmt11.executeUpdate(sqlquery3);
 
break;
   
}
			
			
			
		}
			

		}

	
		
	

